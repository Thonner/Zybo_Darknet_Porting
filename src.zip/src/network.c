/*
 * network.c
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */
#include "darknet.h"
#include "parser.h"
network *load_network(){
	network *net = parse_network_cfg();
}



