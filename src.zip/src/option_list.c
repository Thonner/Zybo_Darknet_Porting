/*
 * option_list.c
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "option_list.h"
#include "darknet.h"
#include "list.h"

void option_insert(list *l, char *key, char *val)
{
    kvp *p = (kvp*)malloc(sizeof(kvp));
    p->key = key;
    p->val = val;
    p->used = 0;
    list_insert(l, p);
}
list *read_data_cfg(){
	list *options = make_list();

	option_insert(options, "classes", "80");
	option_insert(options, "train", "/home/pjreddie/data/coco/trainvalno5k.txt");
	option_insert(options, "valid", "coco_testdev");
	option_insert(options, "names", "data/coco.names");
	option_insert(options, "backup", "/home/pjreddie/backup/");

	return options;
}



