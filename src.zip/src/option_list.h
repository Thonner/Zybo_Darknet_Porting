/*
 * option_list.h
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */
#include "darknet.h"
#ifndef SRC_OPTION_LIST_H_
#define SRC_OPTION_LIST_H_

typedef struct{
    char *key;
    char *val;
    int used;
} kvp;

void option_insert(list *l, char *key, char *val);

list * read_data_cfg();

#endif /* SRC_OPTION_LIST_H_ */
