/*
 * detector.h
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */

#ifndef SRC_DETECTOR_H_
#define SRC_DETECTOR_H_


typedef struct {
    int w;
    int h;
    int c;
    float *data;
} image;

void test_detector();

#endif /* SRC_DETECTOR_H_ */
