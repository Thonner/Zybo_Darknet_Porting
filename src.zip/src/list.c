/*
 * list.c
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */
#include <stdlib.h>
#include <string.h>
#include "list.h"
#include "darknet.h"

list * make_list()
{
	list *l = (list*)malloc(sizeof(list));
	l->size = 0;
	l->front = 0;
	l->back = 0;
	return l;
}

void list_insert(list *l, void *val)
{
	node *new2 = (node*)malloc(sizeof(node));
	new2->val = val;
	new2->next = 0;

	if(!l->back){
		l->front = new2;
		new2->prev = 0;
	}else{
		l->back->next = new2;
		new2->prev = l->back;
	}
	l->back = new2;
	++l->size;
}
