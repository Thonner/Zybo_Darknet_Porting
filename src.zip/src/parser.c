/*
 * parser.c
 *
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "darknet.h"
#include "parser.h"
#include "option_list.h"
#include "list.h"



typedef struct{
    char *type;
    list *options;
}section;

typedef struct size_params{
    int batch;
    int inputs;
    int h;
    int w;
    int c;
    int index;
    int time_steps;
    network *net;
} size_params;

network *make_network(int n)
{
    network *net = (network*)calloc(1, sizeof(network));
    net->n = n;
    net->layers = (layer*)calloc(net->n, sizeof(layer));
    net->seen = (size_t*)calloc(1, sizeof(size_t));
    net->t    = (int*)calloc(1, sizeof(int));
    net->cost = (float*)calloc(1, sizeof(float));
    return net;
}

network *parse_network_cfg(){
	list *sections = read_cfg();
	node *n = sections->front;
	network *net = make_network(sections->size - 1);
	net->gpu_index = -1;
	size_params params;

	section *s = (section *)n->val;
	list *options = s->options;


}


list *read_cfg(){
	char *line;
	list *options = make_list();

	section *current = 0;

	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch", "1" );
	option_insert(current -> options, "subdivisions", "1" );
	option_insert(current -> options, "width", "416" );
	option_insert(current -> options, "height", "416" );
	option_insert(current -> options, "channels", "3" );
	option_insert(current -> options, "momentum", "0.9" );
	option_insert(current -> options, "decay", "0.0005" );
	option_insert(current -> options, "angle", "0" );
	option_insert(current -> options, "saturation", "1.5" );
	option_insert(current -> options, "exposure", "1.5" );
	option_insert(current -> options, "hue", ".1" );
	option_insert(current -> options, "learning_rate", "0.001" );
	option_insert(current -> options, "burn_in", "1000" );
	option_insert(current -> options, "max_batches", "500200" );
	option_insert(current -> options, "policy", "steps" );
	option_insert(current -> options, "steps", "400000,450000" );
	option_insert(current -> options, "scales", ".1,.1" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "16" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "32" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "64" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "128" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "256" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "512" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "2" );
	option_insert(current -> options, "stride", "1" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "1024" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "256" );
	option_insert(current -> options, "size", "1" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "512" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "1" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "filters", "255" );
	option_insert(current -> options, "activation", "linear" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "mask", "3,4,5" );
	option_insert(current -> options, "anchors", "10,14,23,27,37,58,81,82,135,169,344,319" );
	option_insert(current -> options, "classes", "80" );
	option_insert(current -> options, "num", "6" );
	option_insert(current -> options, "jitter", ".3" );
	option_insert(current -> options, "ignore_thresh", ".7" );
	option_insert(current -> options, "truth_thresh", "1" );
	option_insert(current -> options, "random", "1" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "layers", "-4" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "128" );
	option_insert(current -> options, "size", "1" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "stride", "2" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "layers", "-1,8" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "batch_normalize", "1" );
	option_insert(current -> options, "filters", "256" );
	option_insert(current -> options, "size", "3" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "activation", "leaky" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "size", "1" );
	option_insert(current -> options, "stride", "1" );
	option_insert(current -> options, "pad", "1" );
	option_insert(current -> options, "filters", "255" );
	option_insert(current -> options, "activation", "linear" );



	current = (section*)malloc(sizeof(section));
	list_insert(options, current);
	current->options = make_list();
	current->type = line;

	option_insert(current -> options, "mask", "0,1,2" );
	option_insert(current -> options, "anchors", "10,14,23,27,37,58,81,82,135,169,344,319" );
	option_insert(current -> options, "classes", "80" );
	option_insert(current -> options, "num", "6" );
	option_insert(current -> options, "jitter", ".3" );
	option_insert(current -> options, "ignore_thresh", ".7" );
	option_insert(current -> options, "truth_thresh", "1" );
	option_insert(current -> options, "random", "1" );

	return options;
}


