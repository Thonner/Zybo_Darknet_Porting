/*
 * network.h
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */

#ifndef SRC_NETWORK_H_
#define SRC_NETWORK_H_

network *load_network();



#endif /* SRC_NETWORK_H_ */
