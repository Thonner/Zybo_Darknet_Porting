/*
 * parser.h
 *
 *  Created on: Jan 14, 2019
 *      Author: thonner
 */

#ifndef SRC_PARSER_H_
#define SRC_PARSER_H_

network *parse_network_cfg();
list *read_cfg();


#endif /* SRC_PARSER_H_ */
